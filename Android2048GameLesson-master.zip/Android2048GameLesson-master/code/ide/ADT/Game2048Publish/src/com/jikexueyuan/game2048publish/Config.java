package com.jikexueyuan.game2048publish;

public class Config {

	public static final int LINES = 4;
	public static int CARD_WIDTH = 0;
}
